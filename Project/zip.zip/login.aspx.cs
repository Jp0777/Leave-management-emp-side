﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace Project
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            HttpCookie cookie = Request.Cookies["empinfo"];
            if(cookie!=null)
            {
                Email.Text = cookie["email"];
                Password.Text = cookie["pass"];
            }
        }

        protected void SignUp_Click(object sender, EventArgs e)
        {
            Response.Redirect("sign_up.aspx");

        }

        protected void Login_Click(object sender, EventArgs e)
        {
            HttpCookie cookie = Request.Cookies["empinfo"];
            string CS = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlCommand cmd = new SqlCommand("select  count(*) from EmpInfo where email='" + Email.Text + "' and pass='" + Password.Text + "'", con);
                con.Open();
                object userExist = cmd.ExecuteScalar();
                if (Convert.ToInt32(userExist) > 0)
                {
                    Response.Write(cookie["id"]);
                    Session["user"] =cookie["id"];
                    Response.Redirect("~/profile.aspx");
               
                }
                else
                    Response.Write("Unauth");


            }
        }
    }
}