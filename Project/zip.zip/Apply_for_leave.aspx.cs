﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace Project
{
    public partial class Apply_for_leave : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            CompareValidator1.ValueToCompare = DateTime.Now.ToString("dd/MM/yyyy");

            if (Session["user"]==null)
            {
                Response.Redirect("login.aspx");
            }
          
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            

            if (Session["user"] == null)
            {
                Response.Redirect("login.aspx");
            }
           
                string id = Session["user"].ToString();
                string CS = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;
                using (SqlConnection con = new SqlConnection(CS))
                {
                    SqlCommand cmd = new SqlCommand("insert into EmpLeave values(@id,@from,@to,@desc,@type,@status)", con);
                    con.Open();
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.Parameters.AddWithValue("@from", From.Text);
                        cmd.Parameters.AddWithValue("@to", To.Text);
                        cmd.Parameters.AddWithValue("@desc", desc.Text);
                         cmd.Parameters.AddWithValue("@status", "Pending For Approval");
                         cmd.Parameters.AddWithValue("@type", DropDownList1.SelectedValue);
                       cmd.ExecuteNonQuery();

                        
                        DropDownList1.Text = "";
                        From.Text = "";
                        To.Text = "";
                        desc.Text = "";
                    Response.Write("Applied For Leave Successfully");
                    }
                }
            }

        }

       
    
